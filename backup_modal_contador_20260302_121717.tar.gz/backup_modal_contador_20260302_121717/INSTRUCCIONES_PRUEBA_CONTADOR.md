# Instrucciones para Probar el Contador de Registros

## 🧪 Prueba Rápida

### 1. Reiniciar el Servidor

```bash
# Detener el servidor si está corriendo (Ctrl+C)
# Luego reiniciar:
python manage.py runserver
```

### 2. Abrir el Navegador

1. Ir a la página de tablas archivadas
2. Abrir la consola del navegador (F12 → Console)

### 3. Iniciar una Combinación

1. Hacer clic en "Seleccionar y Combinar Tablas Específicas"
2. Seleccionar algunas tablas (por ejemplo: `auth_user`, `auth_group`)
3. Hacer clic en "Combinar Tablas"

### 4. Observar el Progreso

#### En el Modal de Progreso:

Deberías ver algo como:

```
⏳ Combinación en Progreso

Tiempo: 0m 15s

Progreso: Paso 1/3
Tablas seleccionadas: 2
Tabla actual: auth_user
Progreso tabla: 100/450 registros (22%)
Usuarios procesados: 100

💡 Combinación selectiva en progreso
📊 Progreso en tiempo real: Actualizando cada 100 registros procesados.
```

#### En la Consola del Navegador:

Deberías ver logs como:

```
📊 Progreso tiempo real: auth_user 100/450 (22%) - Total combinados: 100
📊 Progreso tiempo real: auth_user 200/450 (44%) - Total combinados: 200
📊 Progreso tiempo real: auth_user 300/450 (67%) - Total combinados: 300
📊 Progreso tiempo real: auth_user 400/450 (89%) - Total combinados: 400
📊 Progreso tiempo real: auth_user 450/450 (100%) - Total combinados: 450
```

### 5. Verificar el Modal de Completado

Cuando termine, deberías ver:

```
✅ Combinación Completada

Total de registros combinados: 450
Tablas procesadas: 2
Usuarios actualizados: 450

Detalles de la Combinación:
- Tipo de combinación: Selectiva
- Grupos creados: 0
- Registros exitosos: 450
- Registros omitidos: 0
- Errores encontrados: 0

Rendimiento:
- Velocidad promedio: 75 reg/seg
- Tiempo de combinación: 1m 30s
```

#### En la Consola:

```
📊 Mostrando modal de combinación completada con datos: {
  registros_combinados: 450,
  usuarios_combinados: 450,
  tablas_procesadas: 2,
  ...
}
✅ Estadísticas actualizadas en el modal
```

## ✅ Checklist de Verificación

- [ ] El contador se actualiza cada 100 registros (no cada 10)
- [ ] Se muestra "Progreso tabla: X/Y registros (Z%)"
- [ ] Se muestra "Tabla actual: nombre_tabla"
- [ ] El mensaje dice "Actualizando cada 100 registros procesados"
- [ ] Las estadísticas finales se muestran correctamente
- [ ] No hay campos vacíos o con "0" cuando deberían tener datos
- [ ] Los logs aparecen en la consola del navegador

## 🐛 Si Algo No Funciona

### El contador no se actualiza:

1. Verificar que el servidor se reinició después de los cambios
2. Limpiar la caché del navegador (Ctrl+Shift+Delete)
3. Hacer hard refresh (Ctrl+F5)

### Las estadísticas no se muestran:

1. Abrir la consola del navegador
2. Buscar errores en rojo
3. Verificar que los elementos del DOM existen:
   ```javascript
   document.getElementById('totalRegistrosCombinados')
   ```

### Los logs no aparecen:

1. Verificar que la consola está en el nivel "Verbose" o "All"
2. Verificar que no hay filtros activos en la consola

## 📊 Prueba con Datos Reales

Si quieres probar con más datos:

1. Seleccionar tablas con muchos registros (>1000)
2. Observar cómo el contador salta de 100 en 100
3. Verificar que el porcentaje se calcula correctamente

## 🎯 Resultado Esperado

- **Actualización cada 100 registros**: Más eficiente, menos carga en el servidor
- **Estadísticas correctas**: Todos los campos muestran datos reales
- **Logs útiles**: Permiten debugging y seguimiento del proceso
- **Experiencia de usuario mejorada**: Información clara y en tiempo real
